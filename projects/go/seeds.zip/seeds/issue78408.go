// compile

// Copyright 2026 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package p

func F() {
A:
	for range (func(func() bool))(nil) {
		_ = func() {
		A:
			goto A
		}
		goto A
	}
}
