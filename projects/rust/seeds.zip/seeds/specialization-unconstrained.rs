//@ compile-flags: -Znext-solver

#![feature(specialization)]

// Do not treat the RHS of a projection-goal as an unconstrained `Certainty::Yes` response
// if the impl is still further specializable.

trait Default {
   type Id;
}

impl<T> Default for T {
   default type Id = T;
}

fn test<T: Default<Id = U>, U>() {}

fn main() {
    test::<u32, ()>();
    //~^ ERROR type mismatch resolving `<u32 as Default>::Id == ()`
}
