// RUN: %empty-directory(%t)
// RUN: %target-swift-frontend %s -module-name Functions -clang-header-expose-decls=all-public -typecheck -verify -emit-clang-header-path %t/functions.h
// RUN: %FileCheck %s < %t/functions.h

// RUN: %check-interop-cxx-header-in-clang(%t/functions.h -DSWIFT_CXX_INTEROP_HIDE_STL_OVERLAY)

public func takeFloat(_ x: Float) {}

public func takesTuple(_ x: (Float, Float)) {}

public func takesVoid(_ x: ()) {}

// CHECK:     takeFloat

public enum MoveOnlyEnum: ~Copyable {
    case a
}

// CHECK: class MoveOnlyEnum { } SWIFT_UNAVAILABLE_MSG("noncopyable enum 'MoveOnlyEnum' can not yet be represented in C++");

public struct MoveOnlyStruct: ~Copyable {
    let x: Int
}

// CHECK: class MoveOnlyStruct { } SWIFT_UNAVAILABLE_MSG("noncopyable struct 'MoveOnlyStruct' can not yet be represented in C++");

public protocol TestProtocol {}

// CHECK: class TestProtocol { } SWIFT_UNAVAILABLE_MSG("protocol 'TestProtocol' can not yet be represented in C++");

// CHECK: // Unavailable in C++: Swift global function 'takesTuple(_:)'. Parameter 'x' of type '(Float, Float)' is not representable in C++.
// CHECK: // Unavailable in C++: Swift global function 'takesVoid(_:)'. Parameter 'x' of type '()' is not representable in C++.

public typealias unsupportedTypeAlias = () -> (Float, Float)

// CHECK: // Unavailable in C++: Swift type alias 'unsupportedTypeAlias'

public struct Container {
    public struct NestedStruct {}
}

public typealias unsupportedTypeAliasNested = Container.NestedStruct

// CHECK: // Unavailable in C++: Swift type alias 'unsupportedTypeAliasNested'
